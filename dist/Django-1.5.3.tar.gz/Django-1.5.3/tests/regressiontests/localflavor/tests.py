from __future__ import absolute_import

from .generic.tests import GenericLocalFlavorTests
