from __future__ import absolute_import

from ..complex_app.models.bar import Bar
