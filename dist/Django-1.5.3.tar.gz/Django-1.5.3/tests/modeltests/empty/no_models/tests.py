from django.test import TestCase


class NoModelTests(TestCase):
    """ A placeholder test case. See modeltests.empty.tests for more info. """
    pass
